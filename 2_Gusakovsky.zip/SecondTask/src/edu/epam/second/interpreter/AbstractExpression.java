package edu.epam.second.interpreter;

public interface AbstractExpression {
    void interpret(Context context);
}
