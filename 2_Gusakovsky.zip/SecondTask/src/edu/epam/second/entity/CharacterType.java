package edu.epam.second.entity;

public enum CharacterType {
    LETTER,
    NUMBER,
    PUNCTUATION
}
