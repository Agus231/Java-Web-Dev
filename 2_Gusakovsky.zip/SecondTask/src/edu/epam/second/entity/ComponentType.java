package edu.epam.second.entity;

public enum ComponentType {
    TEXT,
    PARAGRAPH,
    SENTENCE,
    LEXICALUNIT,
    WORD,
    NUMBER,
    SYMBOL
}
